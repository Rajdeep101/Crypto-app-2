---
name: Language request
about: Help support or improve any language
labels: language, new
assignees: nfdz
---

You can help complete and improve the translations by joining the [Crowdin](https://crowdin.com/project/cryptool) project. If you don't find the language you want there, please request a new one:

**New languages to support**
Specify the region if you think it makes sense, e.g., zh-cn, pt-br.

**Suggests a new distribution/store**
Does it make sense to distribute the application in a new store?