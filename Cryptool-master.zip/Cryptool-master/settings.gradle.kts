pluginManagement {
    repositories {
        google()
        gradlePluginPortal()
        mavenCentral()
    }
}

rootProject.name = "Cryptool"
include(":androidApp")
include(":androidUI")
include(":shared")
