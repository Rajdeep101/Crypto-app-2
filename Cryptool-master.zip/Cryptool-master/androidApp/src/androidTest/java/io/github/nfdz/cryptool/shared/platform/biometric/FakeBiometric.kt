package io.github.nfdz.cryptool.shared.platform.biometric

class FakeBiometric : Biometric {
    override suspend fun authenticate(context: BiometricContext) {
        TODO("Not yet implemented")
    }
}