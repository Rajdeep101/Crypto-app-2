package io.github.nfdz.cryptool.shared.platform.time

actual object Clock {
    actual fun nowInSeconds(): Long {
        TODO("Not yet implemented")
    }

    actual fun nowInMillis(): Long {
        TODO("Not yet implemented")
    }
}