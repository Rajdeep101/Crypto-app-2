package io.github.nfdz.cryptool.shared.platform.biometric

actual class BiometricContext