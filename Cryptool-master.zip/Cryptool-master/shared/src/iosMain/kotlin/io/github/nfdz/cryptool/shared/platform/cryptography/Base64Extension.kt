package io.github.nfdz.cryptool.shared.platform.cryptography

actual fun ByteArray.encodeBase64(): String = TODO()
actual fun String.decodeBase64(): ByteArray = TODO()
