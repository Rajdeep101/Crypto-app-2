package io.github.nfdz.cryptool.shared.platform.cryptography

actual fun ByteArray.decompressGzip(): String = TODO()
actual fun String.compressGzip(): ByteArray = TODO()