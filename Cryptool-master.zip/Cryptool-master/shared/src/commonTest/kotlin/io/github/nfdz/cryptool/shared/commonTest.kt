package io.github.nfdz.cryptool.shared

import kotlin.test.Test
import kotlin.test.assertTrue

class CommonGreetingTest {

    @Test
    fun testExample() {
        assertTrue(true, "Check 'Hello' is mentioned")
    }
}