package io.github.nfdz.cryptool.shared.platform.file

expect abstract class FileUri