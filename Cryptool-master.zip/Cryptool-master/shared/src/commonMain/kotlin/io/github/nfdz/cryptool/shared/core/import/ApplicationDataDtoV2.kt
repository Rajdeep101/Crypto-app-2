package io.github.nfdz.cryptool.shared.core.import

import io.github.nfdz.cryptool.shared.core.export.ApplicationDataDto

internal typealias ApplicationDataDtoV2 = ApplicationDataDto