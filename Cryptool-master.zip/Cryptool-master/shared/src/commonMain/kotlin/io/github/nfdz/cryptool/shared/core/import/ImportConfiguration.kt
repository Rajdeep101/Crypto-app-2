package io.github.nfdz.cryptool.shared.core.import

import io.github.nfdz.cryptool.shared.core.export.ExportConfiguration

typealias ImportConfiguration = ExportConfiguration