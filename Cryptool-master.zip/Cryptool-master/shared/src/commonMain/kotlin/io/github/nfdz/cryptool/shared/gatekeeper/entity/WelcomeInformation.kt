package io.github.nfdz.cryptool.shared.gatekeeper.entity

data class WelcomeInformation(
    val title: String,
    val content: String,
    val welcomeTutorial: Boolean,
)