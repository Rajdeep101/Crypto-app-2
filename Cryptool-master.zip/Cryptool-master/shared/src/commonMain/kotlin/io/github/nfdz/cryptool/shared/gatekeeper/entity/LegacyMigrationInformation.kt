package io.github.nfdz.cryptool.shared.gatekeeper.entity

data class LegacyMigrationInformation(val hasCode: Boolean)