package io.github.nfdz.cryptool.shared.message.entity

enum class MessageOwnership {
    OWN,
    OTHER,
    SYSTEM
}