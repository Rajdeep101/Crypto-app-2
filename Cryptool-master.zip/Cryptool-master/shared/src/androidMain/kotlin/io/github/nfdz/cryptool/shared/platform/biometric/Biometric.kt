package io.github.nfdz.cryptool.shared.platform.biometric

import androidx.fragment.app.FragmentActivity

actual typealias BiometricContext = FragmentActivity