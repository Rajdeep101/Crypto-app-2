package io.github.nfdz.cryptool.shared.platform.file

import android.net.Uri

actual typealias FileUri = Uri
