# Privacy Policy

This privacy policy will explain how we use your data when you use our application.

## What data do we collect?

Cryptool does not collect any data from you. We do not use any third-party software that collects any data.
Your data is very important, and keeping it safe is one of the core high-priority goals of the application.
No use of the internet at all, No logging, No analytics.

## How to contact us

If you have any questions about Cryptool’s privacy policy, the data we hold on you, or you would like to exercise one of your data protection rights, please do not hesitate to contact us.

Email us at: cryptool@nfdz.io